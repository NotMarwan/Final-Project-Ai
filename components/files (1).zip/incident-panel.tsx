"use client"

import { useState, useCallback, useRef, useEffect } from "react"
import {
  MapPin, Camera, Clock, Crosshair,
  ShieldAlert, XCircle, Download, ChevronRight,
  ShieldCheck, Loader2, CheckCircle2, AlertCircle,
  SlidersHorizontal, CheckCheck, Info, X,
  FileSearch, Sparkles,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import type { LiveAlert } from "@/components/video-player"

// ─── Config ───────────────────────────────────────────────────────────────────

const API_BASE          = "http://localhost:8000"
const MAX_POLL_ATTEMPTS = 20
const POLL_INTERVAL_MS  = 1_500
const TOAST_DURATION_MS = 4_500
const THRESHOLD_DEBOUNCE_MS = 400

/**
 * How long (ms) to wait for a VLM_Report SSE event before showing a
 * "timeout" message.  Gemini 1.5 Flash typically responds in 3–8 s.
 */
const VLM_TIMEOUT_MS = 45_000

// ─── Toast system ─────────────────────────────────────────────────────────────

type ToastVariant = "success" | "info" | "error"
interface Toast { id: number; message: string; variant: ToastVariant }

// ─── Export button states ─────────────────────────────────────────────────────

type ExportPhase =
  | { phase: "idle" }
  | { phase: "polling"; attempt: number }
  | { phase: "downloading" }
  | { phase: "done" }
  | { phase: "error"; message: string }

// ─── VLM report states ────────────────────────────────────────────────────────

type VlmState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "ready"; report: string }
  | { status: "timeout" }
  | { status: "error"; message: string }

// ─── Props ────────────────────────────────────────────────────────────────────

interface IncidentPanelProps {
  alert: LiveAlert | null
}

// ─── Component ────────────────────────────────────────────────────────────────

export function IncidentPanel({ alert }: IncidentPanelProps) {
  const [exportState,   setExportState]   = useState<ExportPhase>({ phase: "idle" })
  const [toasts,        setToasts]        = useState<Toast[]>([])
  const [threshold,     setThreshold]     = useState<number>(50)
  const [thresholdBusy, setThresholdBusy] = useState(false)

  // VLM forensic report — keyed per alert so stale reports don't leak
  const [vlmState, setVlmState] = useState<VlmState>({ status: "idle" })

  const toastCounter     = useRef(0)
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const vlmTimerRef      = useRef<ReturnType<typeof setTimeout> | null>(null)

  // ── VLM SSE listener ──────────────────────────────────────────────────────
  /**
   * Open a dedicated EventSource connection just to receive VLM_Report events.
   * This runs independently of the alert SSE in page.tsx so we don't need to
   * thread extra props through the component tree.
   *
   * The VLM_Report payload shape: { "type": "VLM_Report", "id": "alert-xxx", "report": "..." }
   */
  useEffect(() => {
    const es = new EventSource(`${API_BASE}/alerts`)

    es.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        if (data.type !== "VLM_Report") return
        // Only apply to the currently displayed alert
        setVlmState((prev) => {
          // Accept the report regardless of prev state — a late-arriving report
          // for the current alert should always replace the loading/timeout state.
          return { status: "ready", report: data.report }
        })
        // Cancel the timeout guard since we got the report
        if (vlmTimerRef.current !== null) clearTimeout(vlmTimerRef.current)
      } catch { /* ignore malformed data / ping comments */ }
    }

    es.onerror = () => {
      // Silent — the main SSE in page.tsx will handle reconnect logic.
      // This listener will also naturally reconnect via the browser.
    }

    return () => es.close()
  }, [])   // single subscription for the lifetime of the panel

  // ── Reset VLM state when a new alert arrives ───────────────────────────────
  useEffect(() => {
    if (!alert) {
      setVlmState({ status: "idle" })
      return
    }

    // New incident — immediately show loading state
    setVlmState({ status: "loading" })

    // Safety-net timeout: if the report doesn't arrive within VLM_TIMEOUT_MS
    // (backend may not have Gemini configured) show a graceful fallback.
    if (vlmTimerRef.current !== null) clearTimeout(vlmTimerRef.current)
    vlmTimerRef.current = setTimeout(() => {
      setVlmState((prev) =>
        prev.status === "loading"
          ? { status: "timeout" }
          : prev   // already resolved — don't overwrite
      )
    }, VLM_TIMEOUT_MS)

    // Also reset the export button for the new alert
    setExportState({ phase: "idle" })

    return () => {
      if (vlmTimerRef.current !== null) clearTimeout(vlmTimerRef.current)
    }
  }, [alert?.id])

  // ── Toast helpers ──────────────────────────────────────────────────────────

  const addToast = useCallback((message: string, variant: ToastVariant = "info") => {
    const id = ++toastCounter.current
    setToasts((prev) => [...prev, { id, message, variant }])
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), TOAST_DURATION_MS)
  }, [])

  const dismissToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id))
  }, [])

  // ── Action handlers ────────────────────────────────────────────────────────

  const handleDispatch = useCallback(() => {
    if (!alert) return
    addToast(`🚨 Security team dispatched to ${alert.cameraId}!`, "success")
  }, [alert, addToast])

  const handleFalseAlarm = useCallback(() => {
    addToast("Incident marked as false alarm and logged.", "info")
  }, [addToast])

  const handleExportEvidence = useCallback(async () => {
    if (!alert) return
    if (exportState.phase !== "idle" && exportState.phase !== "done" && exportState.phase !== "error") return

    setExportState({ phase: "polling", attempt: 1 })

    for (let attempt = 1; attempt <= MAX_POLL_ATTEMPTS; attempt++) {
      try {
        const res = await fetch(`${API_BASE}/download_evidence/${alert.id}`)

        if (res.status === 202) {
          if (attempt >= MAX_POLL_ATTEMPTS) {
            setExportState({ phase: "error", message: "Server taking too long — retry later." })
            return
          }
          setExportState({ phase: "polling", attempt: attempt + 1 })
          await _sleep(POLL_INTERVAL_MS)
          continue
        }

        if (!res.ok) {
          const body = await res.json().catch(() => ({}))
          const msg  = body?.detail ?? `Server error ${res.status}`
          setExportState({ phase: "error", message: msg })
          addToast(`Export failed: ${msg}`, "error")
          return
        }

        setExportState({ phase: "downloading" })
        const blob    = await res.blob()
        const blobUrl = URL.createObjectURL(blob)
        const anchor  = document.createElement("a")
        anchor.href     = blobUrl
        anchor.download = `${alert.id}.mp4`
        document.body.appendChild(anchor)
        anchor.click()
        document.body.removeChild(anchor)
        setTimeout(() => URL.revokeObjectURL(blobUrl), 5_000)

        setExportState({ phase: "done" })
        addToast("Evidence clip downloaded successfully.", "success")
        setTimeout(() => setExportState({ phase: "idle" }), 4_000)
        return

      } catch (err) {
        const msg = err instanceof Error ? err.message : "Network error — is the API running?"
        setExportState({ phase: "error", message: msg })
        addToast(msg, "error")
        return
      }
    }
  }, [alert, exportState.phase, addToast])

  // ── Threshold slider ────────────────────────────────────────────────────────

  const sendThreshold = useCallback(async (value: number) => {
    setThresholdBusy(true)
    try {
      const res = await fetch(`${API_BASE}/set_threshold`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ threshold: value / 100 }),
      })
      if (!res.ok) {
        const body = await res.json().catch(() => ({}))
        addToast(`Could not update threshold: ${body?.detail ?? res.status}`, "error")
      } else {
        addToast(`AI sensitivity set to ${value}%`, "success")
      }
    } catch {
      addToast("Cannot reach API — threshold not updated.", "error")
    } finally {
      setThresholdBusy(false)
    }
  }, [addToast])

  const handleThresholdChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number(e.target.value)
    setThreshold(value)
    if (debounceTimerRef.current !== null) clearTimeout(debounceTimerRef.current)
    debounceTimerRef.current = setTimeout(() => sendThreshold(value), THRESHOLD_DEBOUNCE_MS)
  }, [sendThreshold])

  useEffect(() => () => {
    if (debounceTimerRef.current !== null) clearTimeout(debounceTimerRef.current)
  }, [])

  // ── Render: no active incident ─────────────────────────────────────────────
  if (!alert) {
    return (
      <div className="relative flex h-full flex-col">
        <NoIncidentState />
        <div className="border-t border-border p-3">
          <ThresholdSlider value={threshold} busy={thresholdBusy} onChange={handleThresholdChange} />
        </div>
        <ToastStack toasts={toasts} onDismiss={dismissToast} />
      </div>
    )
  }

  // ── Render: active incident ────────────────────────────────────────────────
  return (
    <div className="relative flex h-full flex-col gap-3 overflow-y-auto p-3">

      {/* ── Incident Details ──────────────────────────────────────────── */}
      <div className="rounded-lg border border-border bg-card">
        <div className="flex items-center gap-2 border-b border-border px-3 py-2">
          <Crosshair className="h-3.5 w-3.5 text-primary" />
          <span className="text-xs font-semibold text-foreground">Incident Details</span>
          <Badge
            className={cn(
              "ml-auto h-5 border px-1.5 font-mono text-[9px] uppercase",
              alert.severity === "critical"
                ? "border-danger/30 bg-danger/20 text-danger"
                : alert.severity === "high"
                ? "border-warning/30 bg-warning/20 text-warning"
                : "border-primary/30 bg-primary/20 text-primary"
            )}
          >
            {alert.severity}
          </Badge>
        </div>
        <div className="flex flex-col gap-2.5 p-3">
          <MetadataRow icon={<Camera className="h-3.5 w-3.5" />} label="Camera"
            value={`${alert.cameraId} — ${alert.location}`} />
          <MetadataRow icon={<Clock className="h-3.5 w-3.5" />}  label="Detected At"
            value={alert.timestamp} />
          <MetadataRow icon={<Crosshair className="h-3.5 w-3.5" />} label="Event Type"
            value="Violence Detected" />

          {/* Confidence bar */}
          <div className="mt-1 rounded-md bg-secondary/50 p-2">
            <div className="mb-1.5 flex items-center justify-between">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                Model Confidence
              </span>
              <span className="font-mono text-[11px] font-semibold text-danger">
                {alert.confidence.toFixed(1)}%
              </span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className={cn(
                  "h-full rounded-full transition-all duration-500",
                  alert.severity === "critical" ? "bg-danger"
                  : alert.severity === "high"   ? "bg-warning"
                  : "bg-primary"
                )}
                style={{ width: `${alert.confidence}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          AI FORENSIC REPORT  (driven by Gemini VLM)
          ══════════════════════════════════════════════════════════════════ */}
      <div className="rounded-lg border border-border bg-card overflow-hidden">
        {/* Header */}
        <div className="flex items-center gap-2 border-b border-border px-3 py-2">
          <FileSearch className="h-3.5 w-3.5 text-primary" />
          <span className="text-xs font-semibold text-foreground">AI Forensic Report</span>
          <div className="ml-auto flex items-center gap-1.5">
            <Sparkles className="h-3 w-3 text-primary/60" />
            <span className="font-mono text-[9px] text-muted-foreground uppercase tracking-wider">
              Gemini 1.5 Flash
            </span>
          </div>
        </div>

        {/* Body — state-driven */}
        <div className="p-3">
          {vlmState.status === "loading" && (
            <div className="flex flex-col items-center gap-2.5 py-3">
              {/* Pulsing brain animation */}
              <div className="relative flex h-8 w-8 items-center justify-center">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary/30" />
                <Sparkles className="relative h-4 w-4 text-primary animate-pulse" />
              </div>
              <div className="text-center">
                <p className="text-xs font-medium text-foreground">
                  Generating forensic analysis…
                </p>
                <p className="mt-0.5 text-[10px] text-muted-foreground">
                  Sending CCTV frame to Gemini Vision AI
                </p>
              </div>
              {/* Animated shimmer bars to suggest text loading */}
              <div className="w-full space-y-1.5 pt-1">
                <div className="h-2 w-full animate-pulse rounded bg-secondary" />
                <div className="h-2 w-[85%] animate-pulse rounded bg-secondary [animation-delay:0.1s]" />
                <div className="h-2 w-[70%] animate-pulse rounded bg-secondary [animation-delay:0.2s]" />
              </div>
            </div>
          )}

          {vlmState.status === "ready" && (
            <div className="space-y-2">
              <div
                className={cn(
                  "rounded-md border border-primary/20 bg-primary/5 p-2.5",
                )}
              >
                <p className="text-[11px] leading-relaxed text-foreground/90">
                  {vlmState.report}
                </p>
              </div>
              <p className="flex items-center gap-1 text-[9px] text-muted-foreground">
                <CheckCircle2 className="h-3 w-3 text-success" />
                Analysis generated by Gemini 1.5 Flash
              </p>
            </div>
          )}

          {vlmState.status === "timeout" && (
            <div className="flex items-start gap-2 rounded-md border border-border bg-secondary/30 p-2.5">
              <Info className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-muted-foreground" />
              <p className="text-[11px] leading-relaxed text-muted-foreground">
                Forensic analysis unavailable. Ensure{" "}
                <code className="rounded bg-secondary px-0.5 text-[10px]">GEMINI_API_KEY</code>{" "}
                is set and the{" "}
                <code className="rounded bg-secondary px-0.5 text-[10px]">google-generativeai</code>{" "}
                package is installed on the server.
              </p>
            </div>
          )}

          {vlmState.status === "error" && (
            <div className="flex items-start gap-2 rounded-md border border-danger/20 bg-danger/5 p-2.5">
              <AlertCircle className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-danger" />
              <p className="text-[11px] leading-relaxed text-danger/80">
                {vlmState.message}
              </p>
            </div>
          )}

          {vlmState.status === "idle" && (
            <p className="py-2 text-center text-[10px] text-muted-foreground">
              Awaiting incident detection…
            </p>
          )}
        </div>
      </div>

      {/* ── Floor plan ────────────────────────────────────────────────── */}
      <div className="overflow-hidden rounded-lg border border-border bg-card">
        <div className="flex items-center gap-2 border-b border-border px-3 py-2">
          <MapPin className="h-3.5 w-3.5 text-primary" />
          <span className="text-xs font-semibold text-foreground">Camera Location</span>
        </div>
        <div className="p-3">
          <svg viewBox="0 0 100 70" className="w-full" aria-label="Floor plan">
            <rect x="5" y="5" width="90" height="60" rx="1"
              fill="none" stroke="#334155" strokeWidth="0.5" />
            {[
              { x: 5,  y: 5,  w: 30, h: 30, label: "Zone A" },
              { x: 35, y: 5,  w: 30, h: 30, label: "Zone B" },
              { x: 65, y: 5,  w: 30, h: 30, label: "Zone C" },
              { x: 5,  y: 35, w: 45, h: 30, label: "Zone D" },
              { x: 50, y: 35, w: 45, h: 30, label: "Zone E" },
            ].map((r) => (
              <g key={r.label}>
                <rect x={r.x} y={r.y} width={r.w} height={r.h} rx="0.5"
                  fill="rgba(30,41,59,0.5)" stroke="#334155" strokeWidth="0.3" />
                <text x={r.x + r.w / 2} y={r.y + r.h / 2 + 1}
                  textAnchor="middle" fontSize="3" fontFamily="monospace" fill="#64748b">
                  {r.label}
                </text>
              </g>
            ))}
            <circle cx="20" cy="20" r="5" fill="rgba(239,68,68,0.15)">
              <animate attributeName="r"       values="3;7;3"     dur="2s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.5;0;0.5" dur="2s" repeatCount="indefinite" />
            </circle>
            <circle cx="20" cy="20" r="2.5" fill="#ef4444" stroke="#0f172a" strokeWidth="0.5" />
            <text x="20" y="14" textAnchor="middle" fontSize="2.5"
              fontFamily="monospace" fontWeight="bold" fill="#ef4444">
              {alert.cameraId}
            </text>
          </svg>
        </div>
      </div>

      {/* ── AI Sensitivity slider ──────────────────────────────────────── */}
      <ThresholdSlider value={threshold} busy={thresholdBusy} onChange={handleThresholdChange} />

      {/* ── Action buttons ────────────────────────────────────────────── */}
      <div className="flex flex-col gap-2">
        <Button
          onClick={handleDispatch}
          className="h-11 w-full gap-2 bg-danger font-semibold text-sm text-danger-foreground shadow-lg shadow-danger/20 transition-all hover:bg-danger/90 active:scale-[0.98]"
        >
          <ShieldAlert className="h-4 w-4" />
          DISPATCH SECURITY TEAM
          <ChevronRight className="ml-auto h-4 w-4" />
        </Button>

        <div className="flex gap-2">
          <Button variant="secondary" onClick={handleFalseAlarm}
            className="h-9 flex-1 gap-1.5 bg-secondary text-xs text-secondary-foreground transition-all hover:bg-secondary/80 active:scale-[0.97]">
            <XCircle className="h-3.5 w-3.5" />
            Mark False Alarm
          </Button>

          <Button variant="outline" onClick={handleExportEvidence}
            disabled={exportState.phase === "polling" || exportState.phase === "downloading"}
            className={cn(
              "h-9 flex-1 gap-1.5 border-border text-xs transition-all active:scale-[0.97]",
              exportState.phase === "done"
                ? "border-success/40 bg-success/10 text-success hover:bg-success/20"
                : exportState.phase === "error"
                ? "border-danger/40 bg-danger/10 text-danger hover:bg-danger/20"
                : "text-foreground hover:bg-secondary"
            )}
          >
            <ExportButtonContent state={exportState} />
          </Button>
        </div>
      </div>

      {/* ── Toast stack ───────────────────────────────────────────────── */}
      <ToastStack toasts={toasts} onDismiss={dismissToast} />
    </div>
  )
}

// ─── Threshold slider ─────────────────────────────────────────────────────────

function ThresholdSlider({
  value, busy, onChange,
}: {
  value:    number
  busy:     boolean
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
}) {
  const trackColor =
    value < 40 ? "#22c55e" : value < 65 ? "#f59e0b" : "#ef4444"

  return (
    <div className="rounded-lg border border-border bg-card p-3">
      <div className="mb-2 flex items-center gap-2">
        <SlidersHorizontal className="h-3.5 w-3.5 text-primary" />
        <span className="text-xs font-semibold text-foreground">AI Sensitivity</span>
        {busy
          ? <Loader2 className="ml-auto h-3 w-3 animate-spin text-muted-foreground" />
          : <span className="ml-auto font-mono text-[11px] font-bold" style={{ color: trackColor }}>
              {value}%
            </span>
        }
      </div>
      <input
        type="range" min={10} max={95} step={1} value={value}
        onChange={onChange} aria-label="Detection threshold"
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-secondary outline-none"
        style={{
          background: `linear-gradient(to right,${trackColor} 0%,${trackColor} ${
            ((value - 10) / 85) * 100
          }%,rgb(30 41 59) ${((value - 10) / 85) * 100}%,rgb(30 41 59) 100%)`,
        }}
      />
      <div className="mt-1 flex justify-between">
        <span className="text-[9px] text-muted-foreground">Low (10%)</span>
        <span className="text-[9px] text-muted-foreground">Strict (95%)</span>
      </div>
      <p className="mt-1.5 text-[10px] leading-relaxed text-muted-foreground">
        {value < 40
          ? "High sensitivity — may flag ambiguous scenes."
          : value < 65
          ? "Balanced — recommended for most deployments."
          : "Strict — only flags high-confidence violence events."}
      </p>
    </div>
  )
}

// ─── Toast stack ─────────────────────────────────────────────────────────────

function ToastStack({ toasts, onDismiss }: { toasts: Toast[]; onDismiss: (id: number) => void }) {
  if (toasts.length === 0) return null
  return (
    <div className="sticky bottom-0 left-0 right-0 z-50 flex flex-col gap-1.5 pb-1 pt-2">
      {toasts.map((t) => {
        const styles: Record<ToastVariant, string> = {
          success: "border-success/30 bg-success/10 text-success",
          info:    "border-primary/30 bg-primary/10 text-primary",
          error:   "border-danger/30  bg-danger/10  text-danger",
        }
        const Icon = t.variant === "success" ? CheckCheck
                   : t.variant === "error"   ? AlertCircle : Info
        return (
          <div key={t.id}
            className={cn(
              "flex items-start gap-2 rounded-lg border px-3 py-2 text-[11px] shadow-lg",
              styles[t.variant]
            )}
          >
            <Icon className="mt-0.5 h-3.5 w-3.5 flex-shrink-0" />
            <span className="flex-1 leading-relaxed">{t.message}</span>
            <button onClick={() => onDismiss(t.id)}
              className="mt-0.5 opacity-60 transition-opacity hover:opacity-100"
              aria-label="Dismiss">
              <X className="h-3 w-3" />
            </button>
          </div>
        )
      })}
    </div>
  )
}

// ─── Export button label ──────────────────────────────────────────────────────

function ExportButtonContent({ state: s }: { state: ExportPhase }) {
  switch (s.phase) {
    case "idle":        return <><Download    className="h-3.5 w-3.5" />Export Evidence</>
    case "polling":     return <><Loader2     className="h-3.5 w-3.5 animate-spin" />Compiling… ({s.attempt}/{MAX_POLL_ATTEMPTS})</>
    case "downloading": return <><Loader2     className="h-3.5 w-3.5 animate-spin" />Downloading…</>
    case "done":        return <><CheckCircle2 className="h-3.5 w-3.5" />Downloaded!</>
    case "error":       return <><AlertCircle className="h-3.5 w-3.5" />Retry Export</>
  }
}

// ─── Empty-state panel ────────────────────────────────────────────────────────

function NoIncidentState() {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4 p-6 text-center">
      <ShieldCheck className="h-10 w-10 text-muted-foreground/30" />
      <div>
        <p className="text-sm font-medium text-muted-foreground">No Active Incident</p>
        <p className="mt-1 text-xs text-muted-foreground/60">
          Details will appear here when violence is detected.
        </p>
      </div>
    </div>
  )
}

// ─── MetadataRow ──────────────────────────────────────────────────────────────

function MetadataRow({ icon, label, value }: {
  icon: React.ReactNode; label: string; value: string
}) {
  return (
    <div className="flex items-start gap-2">
      <span className="mt-0.5 text-muted-foreground">{icon}</span>
      <div className="flex flex-col">
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
        <span className="text-xs font-medium text-foreground">{value}</span>
      </div>
    </div>
  )
}

// ─── Utility ──────────────────────────────────────────────────────────────────

const _sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms))
