"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import {
  Repeat, Timer, Radio, Play, Pause, Maximize2,
  WifiOff, Loader2, Camera,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

// ─── Types ────────────────────────────────────────────────────────────────────

export interface LiveAlert {
  id:         string
  timestamp:  string
  isoTime:    string
  confidence: number
  type:       "Violence"
  severity:   "critical" | "high" | "medium"
  cameraId:   string
  location:   string
}

interface VideoPlayerProps {
  activeAlert: LiveAlert | null
  privacyMode: boolean
}

// ─── Constants ────────────────────────────────────────────────────────────────

const API_BASE        = "http://localhost:8000"
const VIDEO_FEED_URL  = `${API_BASE}/video_feed`
const OVERLAY_LINGER_MS = 8_000   // ms the violence overlay persists after last alert

/**
 * Delay (ms) between /switch_camera POST and forcing the <img> to reconnect.
 * Gives the backend one frame-period to release the old cap and open the new one.
 */
const SWITCH_SETTLE_MS = 900

// ─── Camera definitions ───────────────────────────────────────────────────────

const CAMERAS = [
  { id: "CAM-01", label: "CAM-01" },
  { id: "CAM-02", label: "CAM-02" },
  { id: "CAM-03", label: "CAM-03" },
] as const

type CameraId = (typeof CAMERAS)[number]["id"]

// ─── Component ────────────────────────────────────────────────────────────────

export function VideoPlayer({ activeAlert, privacyMode }: VideoPlayerProps) {
  // ── Playback state ──────────────────────────────────────────────────────────
  const [isPlaying,     setIsPlaying]     = useState(true)
  const [activeControl, setActiveControl] = useState<string | null>(null)
  const [streamError,   setStreamError]   = useState(false)

  /**
   * streamKey is incremented whenever we want to force the browser to open a
   * fresh HTTP connection to /video_feed (e.g. after a camera switch).
   * React re-mounts the <img> element when its key changes.
   */
  const [streamKey, setStreamKey] = useState(0)

  // ── Camera selector state ────────────────────────────────────────────────────
  const [activeCamId,  setActiveCamId]  = useState<CameraId>("CAM-01")
  const [isSwitching,  setIsSwitching]  = useState(false)
  const [switchError,  setSwitchError]  = useState<string | null>(null)

  // ── Violence overlay state ───────────────────────────────────────────────────
  const [showViolence, setShowViolence] = useState(false)
  const [visibleAlert, setVisibleAlert] = useState<LiveAlert | null>(null)
  const lingerTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    if (activeAlert === null) return

    setShowViolence(true)
    setVisibleAlert(activeAlert)

    if (lingerTimerRef.current !== null) clearTimeout(lingerTimerRef.current)
    lingerTimerRef.current = setTimeout(() => setShowViolence(false), OVERLAY_LINGER_MS)

    return () => {
      if (lingerTimerRef.current !== null) clearTimeout(lingerTimerRef.current)
    }
  }, [activeAlert?.id])

  const confidence = visibleAlert?.confidence ?? 0
  const cameraId   = visibleAlert?.cameraId   ?? activeCamId
  const timestamp  = visibleAlert?.timestamp  ?? "--:--:-- UTC"

  // ── Camera switch handler ───────────────────────────────────────────────────
  const handleCameraSwitch = useCallback(async (camId: CameraId) => {
    if (camId === activeCamId || isSwitching) return

    setIsSwitching(true)
    setSwitchError(null)

    try {
      const res = await fetch(`${API_BASE}/switch_camera`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ camera_id: camId }),
      })

      if (!res.ok) {
        const body = await res.json().catch(() => ({}))
        throw new Error(body?.detail ?? `Server returned ${res.status}`)
      }

      // Give the backend SWITCH_SETTLE_MS to open the new capture
      await new Promise<void>((r) => setTimeout(r, SWITCH_SETTLE_MS))

      setActiveCamId(camId)
      setStreamError(false)
      // Force the <img> to open a fresh connection — clears any buffered frames
      setStreamKey((k) => k + 1)

    } catch (err) {
      const msg = err instanceof Error ? err.message : "Camera switch failed"
      setSwitchError(msg)
      // Auto-clear the error message after 4 s
      setTimeout(() => setSwitchError(null), 4_000)
    } finally {
      setIsSwitching(false)
    }
  }, [activeCamId, isSwitching])

  // ── Stream URL (append streamKey as cache-buster) ──────────────────────────
  const streamSrc = isPlaying ? `${VIDEO_FEED_URL}?k=${streamKey}` : undefined

  return (
    <div className="flex h-full flex-col">

      {/* ══════════════════════════════════════════════════════════════════
          CAMERA SELECTOR BAR
          ══════════════════════════════════════════════════════════════════ */}
      <div className="flex items-center gap-1.5 border-b border-border bg-card/80 px-3 py-1.5">
        <Camera className="h-3.5 w-3.5 flex-shrink-0 text-muted-foreground" />
        <span className="mr-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
          Camera
        </span>

        {CAMERAS.map((cam) => {
          const isActive = activeCamId === cam.id
          return (
            <button
              key={cam.id}
              onClick={() => handleCameraSwitch(cam.id)}
              disabled={isSwitching}
              aria-pressed={isActive}
              className={cn(
                "flex items-center gap-1.5 rounded border px-2.5 py-0.5",
                "font-mono text-[11px] font-semibold transition-all duration-200",
                "disabled:pointer-events-none disabled:opacity-50",
                isActive
                  ? "border-primary/50 bg-primary/15 text-primary"
                  : "border-transparent text-muted-foreground hover:border-border hover:bg-secondary hover:text-foreground"
              )}
            >
              {/* Live indicator dot */}
              <span
                className={cn(
                  "h-1.5 w-1.5 rounded-full transition-colors",
                  isActive ? "bg-primary animate-pulse" : "bg-muted-foreground/30"
                )}
              />
              {cam.label}
            </button>
          )
        })}

        {/* Switching status — shows while the swap is in progress */}
        {isSwitching && (
          <span className="ml-auto flex items-center gap-1.5 font-mono text-[10px] text-primary">
            <Loader2 className="h-3 w-3 animate-spin" />
            Connecting…
          </span>
        )}

        {/* Transient switch error */}
        {switchError && !isSwitching && (
          <span className="ml-auto font-mono text-[10px] text-danger">
            ✗ {switchError}
          </span>
        )}
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          STATUS BANNER
          ══════════════════════════════════════════════════════════════════ */}
      <div
        className={cn(
          "flex items-center gap-2 border-b px-4 py-2 transition-all duration-700",
          showViolence
            ? "border-danger/40 bg-danger/10"
            : "border-border bg-card/60"
        )}
      >
        {showViolence ? (
          <>
            <span className="relative flex h-2.5 w-2.5 flex-shrink-0">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-danger opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-danger" />
            </span>
            <span className="text-sm font-bold tracking-wide text-danger">
              ⚠&nbsp;VIOLENCE DETECTED — CONFIDENCE {confidence.toFixed(1)}%
            </span>
            <div className="ml-auto flex items-center gap-1.5">
              <span className="font-mono text-[10px] uppercase text-danger/70">Live Alert</span>
            </div>
          </>
        ) : (
          <>
            <span className="relative flex h-2.5 w-2.5 flex-shrink-0">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-success" />
            </span>
            <span className="text-sm font-semibold text-success">
              MONITORING — No Threat Detected
            </span>
            <span className="ml-auto font-mono text-[10px] text-muted-foreground">
              {activeCamId} — Live Feed
            </span>
          </>
        )}
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          VIDEO AREA + CSS OVERLAYS
          ══════════════════════════════════════════════════════════════════ */}
      <div className="relative flex-1 overflow-hidden bg-black">

        {/* Privacy overlay */}
        {privacyMode && (
          <div className="absolute inset-0 z-30 flex items-center justify-center backdrop-blur-2xl">
            <span className="rounded-md border border-danger/40 bg-black/60 px-4 py-1.5 font-mono text-sm font-semibold text-danger">
              PRIVACY MODE — FEED REDACTED
            </span>
          </div>
        )}

        {/* Camera switching overlay — shown while the backend is swapping */}
        {isSwitching && (
          <div className="absolute inset-0 z-25 flex flex-col items-center justify-center gap-3 bg-black/70 backdrop-blur-sm">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <div className="text-center">
              <p className="font-mono text-sm font-semibold text-primary">
                Connecting to {activeCamId === "CAM-01" ? "CAM-02" : activeCamId}…
              </p>
              <p className="mt-0.5 font-mono text-[10px] text-muted-foreground">
                Switching video source
              </p>
            </div>
          </div>
        )}

        {/* Stream error fallback */}
        {streamError && !isSwitching && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-background/90">
            <WifiOff className="h-10 w-10 text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground">
              Cannot connect to{" "}
              <code className="rounded bg-secondary px-1 text-xs">{VIDEO_FEED_URL}</code>
            </p>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => { setStreamError(false); setStreamKey((k) => k + 1) }}
            >
              Retry
            </Button>
          </div>
        )}

        {/* Live MJPEG frame — key forces full remount on camera switch */}
        {!streamError && (
          <img
            key={streamKey}
            src={streamSrc}
            alt={`${activeCamId} live CCTV feed`}
            className="h-full w-full object-cover"
            onError={() => setStreamError(true)}
          />
        )}

        {/* ── CSS HUD Overlays (zero OpenCV) ─────────────────────────────── */}

        {/* 1. Pulsing danger border */}
        {showViolence && (
          <div
            className="pointer-events-none absolute inset-0 z-10 border-[3px] border-danger"
            style={{
              boxShadow: "inset 0 0 40px rgba(239,68,68,0.25), 0 0 20px rgba(239,68,68,0.15)",
              animation: "pulse 1.2s ease-in-out infinite",
            }}
          />
        )}

        {/* 2. Scanline vignette */}
        <div
          className={cn(
            "pointer-events-none absolute inset-0 z-10 transition-opacity duration-700",
            showViolence ? "opacity-60" : "opacity-20"
          )}
          style={{
            background:
              "repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,0,0,0.08) 2px,rgba(0,0,0,0.08) 4px)",
          }}
        />

        {/* 3. Central VIOLENCE DETECTED banner */}
        {showViolence && (
          <div className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-start pt-6">
            <div className="flex items-center gap-3 rounded-lg border border-danger/50 bg-black/70 px-6 py-3 backdrop-blur-sm">
              <span className="flex gap-1">
                <span className="h-2 w-2 animate-ping rounded-full bg-danger" />
                <span className="h-2 w-2 animate-ping rounded-full bg-danger [animation-delay:0.15s]" />
                <span className="h-2 w-2 animate-ping rounded-full bg-danger [animation-delay:0.3s]" />
              </span>
              <div className="flex flex-col items-center">
                <span className="font-mono text-base font-black uppercase tracking-[0.3em] text-danger drop-shadow-lg">
                  ⚠ VIOLENCE DETECTED
                </span>
                <span className="font-mono text-[11px] tracking-widest text-danger/70">
                  AI CONFIDENCE: {confidence.toFixed(1)}%&nbsp;·&nbsp;{timestamp}
                </span>
              </div>
              <span className="flex gap-1">
                <span className="h-2 w-2 animate-ping rounded-full bg-danger [animation-delay:0.3s]" />
                <span className="h-2 w-2 animate-ping rounded-full bg-danger [animation-delay:0.15s]" />
                <span className="h-2 w-2 animate-ping rounded-full bg-danger" />
              </span>
            </div>
          </div>
        )}

        {/* 4. Severity chip — top-left */}
        {showViolence && visibleAlert && (
          <div className="pointer-events-none absolute left-3 top-3 z-20">
            <Badge
              className={cn(
                "h-5 border px-2 font-mono text-[9px] uppercase shadow-md backdrop-blur-sm",
                visibleAlert.severity === "critical"
                  ? "border-danger/40  bg-danger/20  text-danger"
                  : visibleAlert.severity === "high"
                  ? "border-warning/40 bg-warning/20 text-warning"
                  : "border-primary/40 bg-primary/20 text-primary"
              )}
            >
              {visibleAlert.severity}
            </Badge>
          </div>
        )}

        {/* 5. REC indicator — top-right */}
        <div className="pointer-events-none absolute right-3 top-3 z-20 flex items-center gap-1.5">
          <span
            className={cn(
              "h-2 w-2 rounded-full",
              showViolence ? "animate-ping bg-danger" : "animate-pulse bg-danger"
            )}
          />
          <span className="font-mono text-[10px] font-bold text-danger drop-shadow">REC</span>
        </div>

        {/* 6. Timestamp + Camera ID — bottom-left */}
        <div className="pointer-events-none absolute bottom-10 left-3 z-20 flex items-center gap-2">
          <span className="font-mono text-[10px] text-white/60 drop-shadow">{timestamp}</span>
          <span className="text-[10px] text-white/30">|</span>
          <span className="font-mono text-[10px] text-primary drop-shadow">{cameraId}</span>
        </div>

        {/* 7. Confidence bar — bottom-right */}
        {showViolence && (
          <div className="pointer-events-none absolute bottom-10 right-3 z-20 flex items-center gap-2">
            <span className="font-mono text-[10px] text-white/50 drop-shadow">CONF</span>
            <div className="h-1.5 w-20 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-danger transition-all duration-500"
                style={{ width: `${confidence}%` }}
              />
            </div>
            <span className="font-mono text-[10px] text-danger drop-shadow">
              {confidence.toFixed(1)}%
            </span>
          </div>
        )}
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          CONTROLS BAR
          ══════════════════════════════════════════════════════════════════ */}
      <div className="flex items-center justify-between border-t border-border bg-card px-4 py-2">
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 text-muted-foreground hover:bg-secondary hover:text-foreground"
            onClick={() => setIsPlaying((p) => !p)}
            aria-label={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
          </Button>
        </div>

        <div className="flex items-center gap-1">
          <ControlButton
            icon={<Repeat className="h-3.5 w-3.5" />}
            label="Loop Clip"
            isActive={activeControl === "loop"}
            onClick={() => setActiveControl(activeControl === "loop" ? null : "loop")}
          />
          <ControlButton
            icon={<Timer className="h-3.5 w-3.5" />}
            label="Slow Motion"
            isActive={activeControl === "slow"}
            onClick={() => setActiveControl(activeControl === "slow" ? null : "slow")}
          />
          <ControlButton
            icon={<Radio className="h-3.5 w-3.5" />}
            label="Live Feed"
            isActive={activeControl === "live"}
            onClick={() => setActiveControl(activeControl === "live" ? null : "live")}
          />
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 text-muted-foreground hover:bg-secondary hover:text-foreground"
            aria-label="Fullscreen"
          >
            <Maximize2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </div>
  )
}

// ─── ControlButton sub-component ─────────────────────────────────────────────

function ControlButton({
  icon, label, isActive, onClick,
}: {
  icon:     React.ReactNode
  label:    string
  isActive: boolean
  onClick:  () => void
}) {
  return (
    <Button
      variant="ghost"
      size="sm"
      className={cn(
        "h-7 gap-1.5 px-2 text-[11px]",
        isActive
          ? "bg-primary/15 text-primary hover:bg-primary/20 hover:text-primary"
          : "text-muted-foreground hover:bg-secondary hover:text-foreground"
      )}
      onClick={onClick}
    >
      {icon}
      <span className="hidden lg:inline">{label}</span>
    </Button>
  )
}
