"""
api.py — SentinelEye FastAPI Backend  (v4 / Multiplexed + VLM Edition)
=======================================================================
Endpoints:
  GET  /video_feed                   →  Clean MJPEG stream (no burned-in overlays)
  GET  /alerts                       →  SSE — violence alerts + VLM forensic reports
  POST /switch_camera                →  Hot-swap active camera without server restart
  GET  /current_camera               →  Returns the currently active camera ID
  POST /set_threshold                →  Dynamically update model sensitivity at runtime
  GET  /download_evidence/{alert_id} →  Download compiled DVR evidence .mp4
  GET  /health                       →  System status

Run:
    uvicorn api:app --host 0.0.0.0 --port 8000 --reload

Env vars:
    CAM1_SOURCE    Path / webcam index for CAM-01   (default "cam1.mp4")
    CAM2_SOURCE    Path / webcam index for CAM-02   (default "cam2.mp4")
    CAM3_SOURCE    Path / webcam index for CAM-03   (default "cam3.mp4")
    WEIGHTS_PATH   Path to best_model.pt            (default "best_model.pt")
    THRESHOLD      Confidence threshold 0–1         (default "0.5")
    STRIDE         Frames between predictions       (default "16")
    GEMINI_API_KEY Google Gemini API key (optional — VLM reports disabled if absent)

v4 changes vs v3:
  • POST /switch_camera  — graceful hot-swap of the active cv2.VideoCapture inside
    capture_loop without restarting the server.  Ring buffer and pipeline are reset.
  • Gemini gemini-1.5-flash integration — on violence detection the first raw frame
    is sent to the VLM in a background daemon thread.  The report is broadcast back
    over the existing /alerts SSE channel as {"type":"VLM_Report", "id":..., "report":...}.
  • ALERT_COOLDOWN kept at 15.0 s as requested.
  • All DVR / ring-buffer / evidence-clip logic is preserved unchanged.
"""

import asyncio
import json
import os
import time
import threading
import queue
from collections import deque
from datetime import datetime, timezone
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncGenerator

import cv2
import numpy as np
import torch

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from pydantic import BaseModel, Field

from inference import ViolenceInferencePipeline, VIOLENCE_CLS

# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

def _parse_source(raw: str) -> str | int:
    """Return int for webcam indices, str for file paths."""
    try:
        return int(raw)
    except ValueError:
        return raw

# Three camera sources — override via env vars
CAMERA_SOURCES: dict[str, str | int] = {
    "CAM-01": _parse_source(os.getenv("CAM1_SOURCE", "cam1.mp4")),
    "CAM-02": _parse_source(os.getenv("CAM2_SOURCE", "cam2.mp4")),
    "CAM-03": _parse_source(os.getenv("CAM3_SOURCE", "cam3.mp4")),
}
DEFAULT_CAMERA_ID = "CAM-01"

WEIGHTS_PATH: str   = os.getenv("WEIGHTS_PATH", "best_model.pt")
THRESHOLD:    float = float(os.getenv("THRESHOLD", "0.5"))
STRIDE:       int   = int(os.getenv("STRIDE", "16"))

JPEG_QUALITY   = 80
TARGET_FPS     = 25
ALERT_COOLDOWN = 15.0          # kept at 15 s as requested

RING_BUFFER_LEN = 150          # ~5 s pre-alert at 30 fps
POST_ALERT_LEN  = 150

EVIDENCE_DIR = Path("evidence_clips")
EVIDENCE_DIR.mkdir(exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
# Gemini VLM setup  (optional — silently disabled when key is absent)
# ─────────────────────────────────────────────────────────────────────────────

GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
GEMINI_ENABLED: bool = bool(GEMINI_API_KEY)

_gemini_model = None  # initialised below if key is present

if GEMINI_ENABLED:
    try:
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_API_KEY)
        _gemini_model = genai.GenerativeModel("gemini-1.5-flash")
        print("[Gemini] ✓ gemini-1.5-flash loaded — forensic reports enabled.")
    except ImportError:
        print("[Gemini] ✗ google-generativeai not installed. "
              "Run: pip install google-generativeai")
        GEMINI_ENABLED = False
    except Exception as exc:
        print(f"[Gemini] ✗ Failed to initialise: {exc}")
        GEMINI_ENABLED = False
else:
    print("[Gemini] API key not set — forensic reports disabled.")

_VLM_PROMPT = (
    "Act as a security expert. Briefly describe the violent incident in this "
    "CCTV frame in one short, professional paragraph. Focus on number of people, "
    "actions, and potential weapons."
)


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic request bodies
# ─────────────────────────────────────────────────────────────────────────────

class ThresholdRequest(BaseModel):
    threshold: float = Field(..., ge=0.10, le=0.95,
                             description="New confidence threshold (0.10 – 0.95)")


class CameraRequest(BaseModel):
    camera_id: str = Field(..., description="One of: CAM-01, CAM-02, CAM-03")


# ─────────────────────────────────────────────────────────────────────────────
# Shared application state
# ─────────────────────────────────────────────────────────────────────────────

class AppState:
    """
    Thread-safe container shared between the capture thread and HTTP handlers.

    v4 additions
    ────────────
    • Camera-switch mechanism: /switch_camera writes a pending (source, cam_id)
      tuple; capture_loop polls and applies it between frames.
    • current_camera_id exposed for the /current_camera endpoint.
    • Pipeline reference (from v3) retained for /set_threshold.
    """

    def __init__(self) -> None:
        # Latest clean JPEG frame for MJPEG delivery
        self._frame_lock: threading.Lock = threading.Lock()
        self._frame_jpg:  bytes | None   = None

        # SSE subscriber queues — one per connected client
        self._aq_lock:      threading.Lock    = threading.Lock()
        self._alert_queues: list[queue.Queue] = []

        # Evidence clip registry  alert_id → "writing" | "ready" | "error"
        self._evidence_lock:   threading.Lock = threading.Lock()
        self._evidence_status: dict[str, str] = {}

        # Live pipeline reference for /set_threshold
        self._pipeline_lock: threading.Lock               = threading.Lock()
        self._pipeline:      ViolenceInferencePipeline | None = None

        # Camera hot-swap
        self._camera_lock:    threading.Lock              = threading.Lock()
        self._pending_switch: tuple[str | int, str] | None = None   # (source, cam_id)
        self._current_cam_id: str                         = DEFAULT_CAMERA_ID

        self.running: bool = False

    # ── MJPEG frame ───────────────────────────────────────────────────────

    def set_frame(self, jpg: bytes) -> None:
        with self._frame_lock:
            self._frame_jpg = jpg

    def get_frame(self) -> bytes | None:
        with self._frame_lock:
            return self._frame_jpg

    # ── SSE pub/sub ───────────────────────────────────────────────────────

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=128)
        with self._aq_lock:
            self._alert_queues.append(q)
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self._aq_lock:
            try:
                self._alert_queues.remove(q)
            except ValueError:
                pass

    def broadcast_alert(self, payload: dict) -> None:
        """Fan-out to every connected SSE client."""
        data = json.dumps(payload)
        with self._aq_lock:
            for q in list(self._alert_queues):
                try:
                    q.put_nowait(data)
                except queue.Full:
                    pass  # slow client — skip rather than block

    # ── Pipeline / threshold ──────────────────────────────────────────────

    def register_pipeline(self, pipeline: ViolenceInferencePipeline) -> None:
        with self._pipeline_lock:
            self._pipeline = pipeline

    def set_threshold(self, value: float) -> float:
        with self._pipeline_lock:
            if self._pipeline is None:
                raise RuntimeError("Pipeline not initialised yet.")
            self._pipeline.threshold = value
            return value

    def get_threshold(self) -> float:
        with self._pipeline_lock:
            return self._pipeline.threshold if self._pipeline else THRESHOLD

    # ── Camera hot-swap ───────────────────────────────────────────────────

    def request_camera_switch(self, source: str | int, camera_id: str) -> None:
        """
        Called by the /switch_camera HTTP handler.
        The capture_loop will pick this up on its next iteration.
        """
        with self._camera_lock:
            self._pending_switch = (source, camera_id)

    def consume_pending_switch(self) -> tuple[str | int, str] | None:
        """
        Called by capture_loop each frame.  Returns the pending switch and
        clears it atomically, or returns None if no switch is pending.
        Updates _current_cam_id immediately so HTTP readers see the new value.
        """
        with self._camera_lock:
            pending = self._pending_switch
            if pending is not None:
                self._pending_switch = None
                self._current_cam_id = pending[1]
            return pending

    def get_current_camera_id(self) -> str:
        with self._camera_lock:
            return self._current_cam_id

    # ── Evidence registry ─────────────────────────────────────────────────

    def mark_evidence_writing(self, alert_id: str) -> None:
        with self._evidence_lock:
            self._evidence_status[alert_id] = "writing"

    def mark_evidence_ready(self, alert_id: str) -> None:
        with self._evidence_lock:
            self._evidence_status[alert_id] = "ready"

    def mark_evidence_error(self, alert_id: str) -> None:
        with self._evidence_lock:
            self._evidence_status[alert_id] = "error"

    def get_evidence_status(self, alert_id: str) -> str | None:
        with self._evidence_lock:
            return self._evidence_status.get(alert_id)

    def evidence_stats(self) -> dict:
        with self._evidence_lock:
            vals = list(self._evidence_status.values())
        return {"ready": vals.count("ready"),
                "writing": vals.count("writing"),
                "error": vals.count("error")}


state = AppState()


# ─────────────────────────────────────────────────────────────────────────────
# Background worker: DVR evidence writer
# ─────────────────────────────────────────────────────────────────────────────

def _write_evidence_clip(
    alert_id:   str,
    pre_frames: list[np.ndarray],
    post_queue: queue.Queue,
    fps:        float,
    width:      int,
    height:     int,
) -> None:
    """Combine pre+post alert frames into evidence_clips/<alert_id>.mp4."""
    out_path = EVIDENCE_DIR / f"{alert_id}.mp4"
    state.mark_evidence_writing(alert_id)
    try:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(out_path), fourcc, fps, (width, height))
        if not writer.isOpened():
            raise IOError(f"VideoWriter could not open: {out_path}")

        for frame in pre_frames:
            writer.write(frame)

        collected = 0
        while collected < POST_ALERT_LEN:
            try:
                frame = post_queue.get(timeout=2.0)
                if frame is None:
                    break
                writer.write(frame)
                collected += 1
            except queue.Empty:
                break

        writer.release()
        state.mark_evidence_ready(alert_id)
        print(f"[evidence] ✓ {alert_id}  "
              f"{len(pre_frames)+collected} frames → {out_path}")
    except Exception as exc:
        state.mark_evidence_error(alert_id)
        print(f"[evidence][ERROR] {alert_id}: {exc}")


# ─────────────────────────────────────────────────────────────────────────────
# Background worker: Gemini VLM forensic report
# ─────────────────────────────────────────────────────────────────────────────

def _call_gemini_vlm(alert_id: str, frame: np.ndarray) -> None:
    """
    Daemon thread target — NEVER blocks the capture_loop.

    1. JPEG-encode the raw frame.
    2. POST to Gemini gemini-1.5-flash with a security-analyst prompt.
    3. Broadcast a VLM_Report SSE payload to all connected clients.

    On any error the report text describes the failure so the frontend can
    display a graceful fallback rather than spinning forever.
    """
    report_text: str

    if not GEMINI_ENABLED or _gemini_model is None:
        # Should never be called when disabled, but guard defensively
        report_text = "[Gemini not configured — forensic analysis unavailable.]"
    else:
        try:
            # Encode frame to JPEG bytes
            ok, jpg_buf = cv2.imencode(
                ".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 85]
            )
            if not ok:
                raise ValueError("cv2.imencode returned False")

            # google-generativeai accepts inline bytes as a dict with
            # mime_type + data keys — no PIL dependency required.
            response = _gemini_model.generate_content([
                _VLM_PROMPT,
                {"mime_type": "image/jpeg", "data": jpg_buf.tobytes()},
            ])
            report_text = response.text.strip()
            print(f"[VLM] ✓ {alert_id}: {report_text[:100]}…")

        except Exception as exc:
            report_text = (
                f"[Forensic analysis failed: {type(exc).__name__}: {exc}]"
            )
            print(f"[VLM][ERROR] {alert_id}: {exc}")

    # Broadcast back over the existing SSE channel — same fan-out as alerts
    state.broadcast_alert({
        "type":   "VLM_Report",
        "id":     alert_id,
        "report": report_text,
    })


# ─────────────────────────────────────────────────────────────────────────────
# Core capture + inference thread
# ─────────────────────────────────────────────────────────────────────────────

def capture_loop() -> None:
    """
    Single long-lived daemon thread.

    v4 additions vs v3:
    • Checks AppState for a pending camera switch after every frame.
      On switch: releases the old cap, opens the new source, resets the ring
      buffer and pipeline — zero server restart required.
    • On each violence trigger: spawns _call_gemini_vlm in a background thread
      (if Gemini is enabled) using the first raw frame from the ring buffer.
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    initial_source = CAMERA_SOURCES[DEFAULT_CAMERA_ID]
    print(f"[capture_loop] device={device}  source={initial_source}  "
          f"weights={WEIGHTS_PATH}  threshold={THRESHOLD}")

    pipeline = ViolenceInferencePipeline(
        weights_path=WEIGHTS_PATH,
        device=device,
        threshold=THRESHOLD,
        stride=STRIDE,
    )
    state.register_pipeline(pipeline)

    cap = cv2.VideoCapture(initial_source)
    if not cap.isOpened():
        print(f"[ERROR] Cannot open initial source: {initial_source}")
        state.running = False
        return

    def _read_cap_props(c: cv2.VideoCapture) -> tuple[float, int, int]:
        fps_val = c.get(cv2.CAP_PROP_FPS) or 25.0
        w       = int(c.get(cv2.CAP_PROP_FRAME_WIDTH))
        h       = int(c.get(cv2.CAP_PROP_FRAME_HEIGHT))
        return fps_val, w, h

    src_fps, width, height = _read_cap_props(cap)
    frame_dur = 1.0 / TARGET_FPS

    ring: deque[np.ndarray] = deque(maxlen=RING_BUFFER_LEN)
    active_post_queues: list[list] = []   # [queue.Queue, frames_remaining]
    last_alert_time = 0.0
    state.running   = True
    print("[capture_loop] Frame loop started.")

    while state.running:
        t0 = time.perf_counter()

        # ── 1. Read one raw frame ──────────────────────────────────────────
        ret, raw = cap.read()
        if not ret:
            # Loop file / handle webcam disconnect
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            pipeline.reset()
            continue

        # ── 2. Feed post-alert evidence queues BEFORE inference ────────────
        still_active: list[list] = []
        for entry in active_post_queues:
            post_q, remaining = entry
            if remaining > 0:
                try:
                    post_q.put_nowait(raw.copy())
                except queue.Full:
                    pass
                entry[1] -= 1
                still_active.append(entry)
        active_post_queues = still_active

        # ── 3. Inference (returns clean frame) ─────────────────────────────
        clean_frame = pipeline.process_frame(raw)

        # ── 4. Update ring buffer ──────────────────────────────────────────
        ring.append(raw.copy())

        # ── 5. JPEG-encode clean frame for MJPEG stream ────────────────────
        ok, jpg_buf = cv2.imencode(
            ".jpg", clean_frame, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY]
        )
        if ok:
            state.set_frame(jpg_buf.tobytes())

        # ── 6. Violence detection & alert dispatch ─────────────────────────
        now = time.time()
        if (
            pipeline._last_label == VIOLENCE_CLS
            and now - last_alert_time > ALERT_COOLDOWN
        ):
            last_alert_time = now
            alert_id  = f"alert-{int(now * 1000)}"
            cam_id    = state.get_current_camera_id()

            alert_payload: dict = {
                "id":         alert_id,
                "timestamp":  datetime.now(timezone.utc).strftime("%H:%M:%S UTC"),
                "isoTime":    datetime.now(timezone.utc).isoformat(),
                "confidence": round(pipeline._last_conf * 100, 1),
                "type":       "Violence",
                "severity":   _severity(pipeline._last_conf),
                "cameraId":   cam_id,
                "location":   (
                    str(CAMERA_SOURCES.get(cam_id, cam_id))
                    if isinstance(CAMERA_SOURCES.get(cam_id), str)
                    else cam_id
                ),
            }
            state.broadcast_alert(alert_payload)

            # DVR: snapshot ring buffer → background evidence writer
            pre_frames: list[np.ndarray] = list(ring)
            post_q: queue.Queue = queue.Queue(maxsize=POST_ALERT_LEN + 32)
            active_post_queues.append([post_q, POST_ALERT_LEN])

            threading.Thread(
                target=_write_evidence_clip,
                args=(alert_id, pre_frames, post_q, src_fps, width, height),
                daemon=True,
                name=f"evidence-{alert_id}",
            ).start()

            # VLM: send first available raw frame to Gemini in background
            if GEMINI_ENABLED and pre_frames:
                vlm_frame = pre_frames[-1].copy()   # most recent pre-alert frame
                threading.Thread(
                    target=_call_gemini_vlm,
                    args=(alert_id, vlm_frame),
                    daemon=True,
                    name=f"vlm-{alert_id}",
                ).start()

            print(f"[capture_loop] ⚡ {alert_id}  cam={cam_id}  "
                  f"conf={pipeline._last_conf:.1%}")

        # ── 7. Hot-swap camera if requested ───────────────────────────────
        pending = state.consume_pending_switch()
        if pending is not None:
            new_source, new_cam_id = pending
            cap.release()
            ring.clear()
            active_post_queues.clear()
            pipeline.reset()

            cap = cv2.VideoCapture(new_source)
            if cap.isOpened():
                src_fps, width, height = _read_cap_props(cap)
                print(f"[capture_loop] 📷 Switched to {new_cam_id} ({new_source})")
            else:
                print(f"[ERROR] Cannot open {new_source} — reverting to {DEFAULT_CAMERA_ID}")
                fallback = CAMERA_SOURCES[DEFAULT_CAMERA_ID]
                cap = cv2.VideoCapture(fallback)
                src_fps, width, height = _read_cap_props(cap)
                # Revert state cam_id
                state.request_camera_switch(fallback, DEFAULT_CAMERA_ID)
                state.consume_pending_switch()

        # ── 8. Frame-rate cap ─────────────────────────────────────────────
        elapsed = time.perf_counter() - t0
        wait    = frame_dur - elapsed
        if wait > 0:
            time.sleep(wait)

    # ── Shutdown: unblock any waiting evidence writers ─────────────────────
    for entry in active_post_queues:
        try:
            entry[0].put_nowait(None)
        except queue.Full:
            pass
    cap.release()
    print("[capture_loop] Thread exited cleanly.")


def _severity(conf: float) -> str:
    if conf >= 0.85: return "critical"
    if conf >= 0.65: return "high"
    return "medium"


# ─────────────────────────────────────────────────────────────────────────────
# FastAPI application
# ─────────────────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    t = threading.Thread(target=capture_loop, daemon=True, name="capture")
    t.start()
    yield
    state.running = False
    t.join(timeout=5)


app = FastAPI(
    title="SentinelEye API",
    description="Violence Detection — Multiplexed MJPEG · SSE · DVR · VLM Reports",
    version="4.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 1 — Clean MJPEG stream
# ─────────────────────────────────────────────────────────────────────────────

async def _mjpeg_generator() -> AsyncGenerator[bytes, None]:
    boundary = b"--frame\r\n"
    while True:
        jpg = state.get_frame()
        if jpg is not None:
            yield (
                boundary
                + b"Content-Type: image/jpeg\r\n"
                + b"Content-Length: " + str(len(jpg)).encode() + b"\r\n"
                + b"\r\n" + jpg + b"\r\n"
            )
        await asyncio.sleep(1 / TARGET_FPS)


@app.get("/video_feed", summary="Clean MJPEG stream", tags=["Stream"])
async def video_feed():
    return StreamingResponse(
        _mjpeg_generator(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={
            "Cache-Control":     "no-cache, no-store, must-revalidate",
            "Pragma":            "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 2 — SSE feed (violence alerts + VLM reports share one channel)
# ─────────────────────────────────────────────────────────────────────────────

async def _sse_generator(q: queue.Queue) -> AsyncGenerator[bytes, None]:
    try:
        last_ping = time.time()
        while True:
            while True:
                try:
                    data = q.get_nowait()
                    yield f"data: {data}\n\n".encode()
                except queue.Empty:
                    break
            if time.time() - last_ping > 15:
                yield b": ping\n\n"
                last_ping = time.time()
            await asyncio.sleep(0.1)
    except asyncio.CancelledError:
        pass
    finally:
        state.unsubscribe(q)


@app.get("/alerts", summary="SSE — alerts + VLM forensic reports", tags=["Stream"])
async def alerts():
    q = state.subscribe()
    return StreamingResponse(
        _sse_generator(q),
        media_type="text/event-stream",
        headers={
            "Cache-Control":     "no-cache",
            "X-Accel-Buffering": "no",
            "Connection":        "keep-alive",
        },
    )


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 3 — Hot-swap camera  (NEW in v4)
# ─────────────────────────────────────────────────────────────────────────────

@app.post(
    "/switch_camera",
    summary="Hot-swap active camera without restarting the server",
    tags=["Control"],
    responses={
        200: {"description": "Switch accepted — takes effect within one frame period"},
        400: {"description": "Unknown camera_id"},
        503: {"description": "Capture loop not running"},
    },
)
async def switch_camera(body: CameraRequest):
    """
    Request a graceful camera switch.

    The capture thread picks this up between frames, releases the current
    cv2.VideoCapture, opens the new source, and resets the ring buffer and
    pipeline.  The MJPEG stream will briefly show the last frame of the old
    camera while the handoff completes (typically < 200 ms).

    Request body:
        { "camera_id": "CAM-02" }

    Response:
        { "camera_id": "CAM-02", "source": "cam2.mp4", "message": "..." }
    """
    if body.camera_id not in CAMERA_SOURCES:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown camera_id '{body.camera_id}'. "
                   f"Valid options: {list(CAMERA_SOURCES.keys())}",
        )
    if not state.running:
        raise HTTPException(
            status_code=503,
            detail="Capture loop is not running. Server may still be starting up.",
        )

    source = CAMERA_SOURCES[body.camera_id]
    state.request_camera_switch(source, body.camera_id)

    print(f"[/switch_camera] Requested switch → {body.camera_id} ({source})")
    return {
        "camera_id": body.camera_id,
        "source":    str(source),
        "message":   f"Switch to {body.camera_id} accepted — takes effect within one frame.",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 4 — Current camera status  (NEW in v4)
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/current_camera", summary="Return active camera ID", tags=["Control"])
async def current_camera():
    cam_id = state.get_current_camera_id()
    return {
        "camera_id": cam_id,
        "source":    str(CAMERA_SOURCES.get(cam_id, "unknown")),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 5 — Live threshold update
# ─────────────────────────────────────────────────────────────────────────────

@app.post(
    "/set_threshold",
    summary="Update model sensitivity threshold at runtime",
    tags=["Control"],
)
async def set_threshold(body: ThresholdRequest):
    try:
        accepted = state.set_threshold(body.threshold)
    except RuntimeError:
        raise HTTPException(
            status_code=503,
            detail="Model pipeline is still initialising. Please retry in a few seconds.",
        )
    print(f"[/set_threshold] threshold → {accepted:.2%}")
    return {"threshold": accepted,
            "message":   f"Threshold updated to {accepted * 100:.1f}%"}


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 6 — Evidence download
# ─────────────────────────────────────────────────────────────────────────────

@app.get(
    "/download_evidence/{alert_id}",
    summary="Download compiled DVR evidence clip",
    tags=["Evidence"],
)
async def download_evidence(alert_id: str):
    if not alert_id.startswith("alert-") or not alert_id[6:].isdigit():
        raise HTTPException(status_code=422, detail="Invalid alert_id format.")

    status = state.get_evidence_status(alert_id)
    if status is None:
        raise HTTPException(status_code=404,
                            detail=f"No evidence record for '{alert_id}'.")
    if status == "writing":
        raise HTTPException(status_code=202,
                            detail="Evidence clip still being compiled. Retry shortly.")
    if status == "error":
        raise HTTPException(status_code=500,
                            detail="Evidence clip write failed on the server.")

    clip_path = EVIDENCE_DIR / f"{alert_id}.mp4"
    if not clip_path.exists():
        raise HTTPException(status_code=404,
                            detail="Evidence file missing on disk.")

    return FileResponse(
        path=str(clip_path),
        media_type="video/mp4",
        filename=f"{alert_id}.mp4",
        headers={"Content-Disposition": f'attachment; filename="{alert_id}.mp4"'},
    )


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 7 — Health check
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/health", summary="System status", tags=["System"])
async def health():
    stats = state.evidence_stats()
    return {
        "status":          "ok" if state.running else "starting",
        "current_camera":  state.get_current_camera_id(),
        "cameras":         {k: str(v) for k, v in CAMERA_SOURCES.items()},
        "threshold":       state.get_threshold(),
        "alert_cooldown":  ALERT_COOLDOWN,
        "gemini_enabled":  GEMINI_ENABLED,
        "device":          "cuda" if torch.cuda.is_available() else "cpu",
        "clips_ready":     stats["ready"],
        "clips_writing":   stats["writing"],
        "clips_error":     stats["error"],
        "evidence_dir":    str(EVIDENCE_DIR.resolve()),
    }
