"""
api.py — SentinelEye FastAPI Backend  (v3 / Clean-Stream Edition)
==================================================================
Endpoints:
  GET  /video_feed                   →  Clean MJPEG stream (no burned-in overlays)
  GET  /alerts                       →  SSE violence alert feed
  POST /set_threshold                →  Dynamically update model sensitivity at runtime
  GET  /download_evidence/{alert_id} →  Download compiled DVR evidence .mp4
  GET  /health                       →  System status + current threshold

Run:
    uvicorn api:app --host 0.0.0.0 --port 8000 --reload

Env vars:
    VIDEO_SOURCE   Path to .mp4 OR integer webcam index  (default "0")
    WEIGHTS_PATH   Path to best_model.pt                 (default "best_model.pt")
    THRESHOLD      Confidence threshold 0–1              (default "0.5")
    STRIDE         Frames between model predictions      (default "16")

v3 changes vs v2:
  • ALERT_COOLDOWN bumped to 60 s — one evidence clip saved per violence event,
    not per 3-second window.
  • inference.py process_frame() now returns clean frames; this file no longer
    needs to call any OpenCV drawing helpers before MJPEG encoding.
  • POST /set_threshold lets the React incident panel slider update the model's
    threshold live without a server restart.
  • CORS updated to allow POST method.
"""

import asyncio
import json
import os
import time
import threading
import queue
from collections import deque
from datetime import datetime, timezone
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncGenerator

import cv2
import numpy as np
import torch

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from pydantic import BaseModel, Field

from inference import ViolenceInferencePipeline, VIOLENCE_CLS

# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

VIDEO_SOURCE: str | int = os.getenv("VIDEO_SOURCE", "0")
try:
    VIDEO_SOURCE = int(VIDEO_SOURCE)
except ValueError:
    pass

WEIGHTS_PATH: str   = os.getenv("WEIGHTS_PATH", "best_model.pt")
THRESHOLD:    float = float(os.getenv("THRESHOLD", "0.5"))
STRIDE:       int   = int(os.getenv("STRIDE", "16"))

JPEG_QUALITY   = 80    # MJPEG encode quality (0–100)
TARGET_FPS     = 25    # Max stream frame-rate

# ── v3: 60 s cooldown — one clip per continuous violence event per minute ─────
ALERT_COOLDOWN = 60.0

# DVR ring-buffer settings
RING_BUFFER_LEN = 150  # Pre-alert raw frames (~5 s @ 30 fps)
POST_ALERT_LEN  = 150  # Post-alert frames captured after trigger

EVIDENCE_DIR = Path("evidence_clips")
EVIDENCE_DIR.mkdir(exist_ok=True)


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic request body for /set_threshold
# ─────────────────────────────────────────────────────────────────────────────

class ThresholdRequest(BaseModel):
    threshold: float = Field(
        ...,
        ge=0.10,
        le=0.95,
        description="New violence confidence threshold (0.10 – 0.95)",
    )


# ─────────────────────────────────────────────────────────────────────────────
# Shared application state
# ─────────────────────────────────────────────────────────────────────────────

class AppState:
    """
    Thread-safe container shared between the capture thread and HTTP handlers.

    v3 additions
    ────────────
    • Holds a reference to the live ViolenceInferencePipeline instance so that
      the /set_threshold endpoint can mutate pipeline.threshold from the async
      event-loop thread safely.
    • The _threshold_lock ensures reads/writes from the HTTP handler and the
      capture thread don't race.
    """

    def __init__(self) -> None:
        # Latest clean JPEG frame for MJPEG delivery
        self._frame_lock: threading.Lock = threading.Lock()
        self._frame_jpg:  bytes | None   = None

        # SSE subscriber queues
        self._aq_lock:      threading.Lock    = threading.Lock()
        self._alert_queues: list[queue.Queue] = []

        # Evidence clip registry  alert_id → "writing" | "ready" | "error"
        self._evidence_lock:   threading.Lock = threading.Lock()
        self._evidence_status: dict[str, str] = {}

        # Live pipeline reference — set by capture_loop after model loads
        self._pipeline_lock: threading.Lock                = threading.Lock()
        self._pipeline:      ViolenceInferencePipeline | None = None

        self.running: bool = False

    # ── Frame ─────────────────────────────────────────────────────────────

    def set_frame(self, jpg: bytes) -> None:
        with self._frame_lock:
            self._frame_jpg = jpg

    def get_frame(self) -> bytes | None:
        with self._frame_lock:
            return self._frame_jpg

    # ── SSE pub/sub ───────────────────────────────────────────────────────

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=64)
        with self._aq_lock:
            self._alert_queues.append(q)
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self._aq_lock:
            try:
                self._alert_queues.remove(q)
            except ValueError:
                pass

    def broadcast_alert(self, payload: dict) -> None:
        data = json.dumps(payload)
        with self._aq_lock:
            for q in list(self._alert_queues):
                try:
                    q.put_nowait(data)
                except queue.Full:
                    pass

    # ── Pipeline / threshold ──────────────────────────────────────────────

    def register_pipeline(self, pipeline: ViolenceInferencePipeline) -> None:
        """Called once from capture_loop after the model is loaded."""
        with self._pipeline_lock:
            self._pipeline = pipeline

    def set_threshold(self, value: float) -> float:
        """
        Thread-safely update the live pipeline threshold.
        Returns the accepted value, or raises RuntimeError if not ready.
        """
        with self._pipeline_lock:
            if self._pipeline is None:
                raise RuntimeError("Pipeline not initialised yet.")
            self._pipeline.threshold = value
            return value

    def get_threshold(self) -> float:
        with self._pipeline_lock:
            if self._pipeline is None:
                return THRESHOLD  # startup default
            return self._pipeline.threshold

    # ── Evidence registry ─────────────────────────────────────────────────

    def mark_evidence_writing(self, alert_id: str) -> None:
        with self._evidence_lock:
            self._evidence_status[alert_id] = "writing"

    def mark_evidence_ready(self, alert_id: str) -> None:
        with self._evidence_lock:
            self._evidence_status[alert_id] = "ready"

    def mark_evidence_error(self, alert_id: str) -> None:
        with self._evidence_lock:
            self._evidence_status[alert_id] = "error"

    def get_evidence_status(self, alert_id: str) -> str | None:
        with self._evidence_lock:
            return self._evidence_status.get(alert_id)

    def evidence_stats(self) -> dict:
        with self._evidence_lock:
            statuses = list(self._evidence_status.values())
        return {
            "ready":   statuses.count("ready"),
            "writing": statuses.count("writing"),
            "error":   statuses.count("error"),
        }


state = AppState()


# ─────────────────────────────────────────────────────────────────────────────
# Evidence writer  (one daemon thread per alert, zero impact on stream)
# ─────────────────────────────────────────────────────────────────────────────

def _write_evidence_clip(
    alert_id:   str,
    pre_frames: list[np.ndarray],
    post_queue: queue.Queue,
    fps:        float,
    width:      int,
    height:     int,
) -> None:
    """
    Background thread target — never called from the async event loop.

    Combines the pre-alert ring-buffer snapshot with up to POST_ALERT_LEN
    raw frames consumed from post_queue, then writes to:

        evidence_clips/<alert_id>.mp4

    Blocks inside the thread until all post-alert frames arrive or a 2-second
    timeout with no new frames triggers early termination.
    """
    out_path = EVIDENCE_DIR / f"{alert_id}.mp4"
    state.mark_evidence_writing(alert_id)

    try:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(out_path), fourcc, fps, (width, height))
        if not writer.isOpened():
            raise IOError(f"VideoWriter could not open: {out_path}")

        for frame in pre_frames:
            writer.write(frame)

        collected = 0
        while collected < POST_ALERT_LEN:
            try:
                frame = post_queue.get(timeout=2.0)
                if frame is None:
                    break
                writer.write(frame)
                collected += 1
            except queue.Empty:
                break

        writer.release()
        state.mark_evidence_ready(alert_id)

        total = len(pre_frames) + collected
        print(
            f"[evidence] ✓ {alert_id}  "
            f"{total} frames ({len(pre_frames)} pre + {collected} post) → {out_path}"
        )

    except Exception as exc:
        state.mark_evidence_error(alert_id)
        print(f"[evidence][ERROR] Failed to write {alert_id}: {exc}")


# ─────────────────────────────────────────────────────────────────────────────
# Capture + inference thread
# ─────────────────────────────────────────────────────────────────────────────

def capture_loop() -> None:
    """
    Single long-lived daemon thread.

    v3 behaviour changes:
    • process_frame() returns a clean frame — no drawing calls needed here.
    • pipeline reference is registered in AppState immediately after loading
      so /set_threshold can mutate it.
    • ALERT_COOLDOWN is 60 s — only one SSE event + one evidence clip per
      continuous violence episode per minute.
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(
        f"[capture_loop] device={device}  source={VIDEO_SOURCE}  "
        f"weights={WEIGHTS_PATH}  threshold={THRESHOLD}"
    )

    pipeline = ViolenceInferencePipeline(
        weights_path=WEIGHTS_PATH,
        device=device,
        threshold=THRESHOLD,
        stride=STRIDE,
    )
    # ── Register so /set_threshold can reach it ───────────────────────────
    state.register_pipeline(pipeline)

    cap = cv2.VideoCapture(VIDEO_SOURCE)
    if not cap.isOpened():
        print(f"[ERROR] Cannot open video source: {VIDEO_SOURCE}")
        state.running = False
        return

    src_fps   = cap.get(cv2.CAP_PROP_FPS) or 25.0
    width     = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height    = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    frame_dur = 1.0 / TARGET_FPS

    ring: deque[np.ndarray] = deque(maxlen=RING_BUFFER_LEN)
    active_post_queues: list[list] = []   # [queue.Queue, frames_remaining]

    last_alert_time = 0.0
    state.running   = True
    print("[capture_loop] Frame loop started.")

    while state.running:
        t0 = time.perf_counter()

        ret, raw = cap.read()
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            pipeline.reset()
            continue

        # Feed post-alert queues BEFORE inference to preserve frame ordering
        still_active: list[list] = []
        for entry in active_post_queues:
            post_q, remaining = entry
            if remaining > 0:
                try:
                    post_q.put_nowait(raw.copy())
                except queue.Full:
                    pass
                entry[1] -= 1
                still_active.append(entry)
        active_post_queues = still_active

        # ── Inference → returns clean frame ──────────────────────────────
        clean_frame = pipeline.process_frame(raw)

        # Update ring buffer (raw, unannotated)
        ring.append(raw.copy())

        # ── JPEG encode CLEAN frame for MJPEG stream ──────────────────────
        ok, jpg_buf = cv2.imencode(
            ".jpg", clean_frame, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY]
        )
        if ok:
            state.set_frame(jpg_buf.tobytes())

        # ── Violence detection — 60 s cooldown ────────────────────────────
        now = time.time()
        if (
            pipeline._last_label == VIOLENCE_CLS
            and now - last_alert_time > ALERT_COOLDOWN
        ):
            last_alert_time = now
            alert_id = f"alert-{int(now * 1000)}"

            payload: dict = {
                "id":         alert_id,
                "timestamp":  datetime.now(timezone.utc).strftime("%H:%M:%S UTC"),
                "isoTime":    datetime.now(timezone.utc).isoformat(),
                "confidence": round(pipeline._last_conf * 100, 1),
                "type":       "Violence",
                "severity":   _severity(pipeline._last_conf),
                "cameraId":   "CAM-01",
                "location":   (
                    str(VIDEO_SOURCE)
                    if isinstance(VIDEO_SOURCE, str)
                    else "Webcam"
                ),
            }
            state.broadcast_alert(payload)

            pre_frames: list[np.ndarray] = list(ring)
            post_q: queue.Queue = queue.Queue(maxsize=POST_ALERT_LEN + 32)
            active_post_queues.append([post_q, POST_ALERT_LEN])

            threading.Thread(
                target=_write_evidence_clip,
                args=(alert_id, pre_frames, post_q, src_fps, width, height),
                daemon=True,
                name=f"evidence-{alert_id}",
            ).start()

            print(
                f"[capture_loop] ⚡ Alert {alert_id}  "
                f"conf={pipeline._last_conf:.1%}  pre_buf={len(pre_frames)}"
            )

        # Frame-rate cap
        elapsed = time.perf_counter() - t0
        wait    = frame_dur - elapsed
        if wait > 0:
            time.sleep(wait)

    for entry in active_post_queues:
        try:
            entry[0].put_nowait(None)
        except queue.Full:
            pass

    cap.release()
    print("[capture_loop] Thread exited cleanly.")


def _severity(conf: float) -> str:
    if conf >= 0.85:
        return "critical"
    if conf >= 0.65:
        return "high"
    return "medium"


# ─────────────────────────────────────────────────────────────────────────────
# FastAPI application
# ─────────────────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    t = threading.Thread(target=capture_loop, daemon=True, name="capture")
    t.start()
    yield
    state.running = False
    t.join(timeout=5)


app = FastAPI(
    title="SentinelEye API",
    description="Violence Detection — Clean MJPEG · SSE alerts · DVR · Live threshold",
    version="3.0.0",
    lifespan=lifespan,
)

# ── CORS: allow GET + POST from the Next.js dev server ───────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],   # POST needed for /set_threshold
    allow_headers=["*"],
)


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 1 — Clean MJPEG stream
# ─────────────────────────────────────────────────────────────────────────────

async def _mjpeg_generator() -> AsyncGenerator[bytes, None]:
    boundary = b"--frame\r\n"
    while True:
        jpg = state.get_frame()
        if jpg is not None:
            yield (
                boundary
                + b"Content-Type: image/jpeg\r\n"
                + b"Content-Length: " + str(len(jpg)).encode() + b"\r\n"
                + b"\r\n"
                + jpg
                + b"\r\n"
            )
        await asyncio.sleep(1 / TARGET_FPS)


@app.get("/video_feed", summary="Clean MJPEG stream — no burned-in overlays", tags=["Stream"])
async def video_feed():
    return StreamingResponse(
        _mjpeg_generator(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={
            "Cache-Control":     "no-cache, no-store, must-revalidate",
            "Pragma":            "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 2 — SSE alert feed
# ─────────────────────────────────────────────────────────────────────────────

async def _sse_generator(q: queue.Queue) -> AsyncGenerator[bytes, None]:
    try:
        last_ping = time.time()
        while True:
            while True:
                try:
                    data = q.get_nowait()
                    yield f"data: {data}\n\n".encode()
                except queue.Empty:
                    break
            if time.time() - last_ping > 15:
                yield b": ping\n\n"
                last_ping = time.time()
            await asyncio.sleep(0.1)
    except asyncio.CancelledError:
        pass
    finally:
        state.unsubscribe(q)


@app.get("/alerts", summary="SSE violence alert feed", tags=["Stream"])
async def alerts():
    q = state.subscribe()
    return StreamingResponse(
        _sse_generator(q),
        media_type="text/event-stream",
        headers={
            "Cache-Control":     "no-cache",
            "X-Accel-Buffering": "no",
            "Connection":        "keep-alive",
        },
    )


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 3 — Live threshold update  (NEW in v3)
# ─────────────────────────────────────────────────────────────────────────────

@app.post(
    "/set_threshold",
    summary="Update model sensitivity threshold at runtime",
    tags=["Control"],
    responses={
        200: {"description": "Threshold updated successfully"},
        503: {"description": "Pipeline not yet initialised — retry after a few seconds"},
    },
)
async def set_threshold(body: ThresholdRequest):
    """
    Dynamically update the model's confidence threshold without restarting
    the server or reloading model weights.

    The change takes effect on the very next prediction window evaluated by
    the capture thread (~one stride period, typically ≤1 s).

    Request body:
        { "threshold": 0.65 }   // float, 0.10 – 0.95

    Response:
        { "threshold": 0.65, "message": "Threshold updated to 65.0%" }
    """
    try:
        accepted = state.set_threshold(body.threshold)
    except RuntimeError:
        raise HTTPException(
            status_code=503,
            detail="Model pipeline is still initialising. Please retry in a few seconds.",
        )

    print(f"[/set_threshold] threshold → {accepted:.2%}")
    return {
        "threshold": accepted,
        "message":   f"Threshold updated to {accepted * 100:.1f}%",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 4 — Evidence download
# ─────────────────────────────────────────────────────────────────────────────

@app.get(
    "/download_evidence/{alert_id}",
    summary="Download compiled DVR evidence clip",
    tags=["Evidence"],
    responses={
        200: {"description": "Evidence .mp4 file ready for download"},
        202: {"description": "Clip is still being compiled — retry shortly"},
        404: {"description": "No evidence record for this alert ID"},
        422: {"description": "Malformed alert_id"},
        500: {"description": "Evidence write failed on server"},
    },
)
async def download_evidence(alert_id: str):
    """
    Returns the DVR evidence clip for *alert_id* as a downloadable .mp4.
    HTTP 202 while the background writer is still collecting post-alert frames.
    """
    if not alert_id.startswith("alert-") or not alert_id[6:].isdigit():
        raise HTTPException(status_code=422, detail="Invalid alert_id format.")

    status = state.get_evidence_status(alert_id)

    if status is None:
        raise HTTPException(
            status_code=404,
            detail=(
                f"No evidence record found for '{alert_id}'. "
                "The alert may have occurred before this server session."
            ),
        )

    if status == "writing":
        raise HTTPException(
            status_code=202,
            detail="Evidence clip is still being compiled. Please retry in a few seconds.",
        )

    if status == "error":
        raise HTTPException(
            status_code=500,
            detail="Evidence clip write failed on the server.",
        )

    clip_path = EVIDENCE_DIR / f"{alert_id}.mp4"
    if not clip_path.exists():
        raise HTTPException(
            status_code=404,
            detail="Evidence file registered as ready but is missing on disk.",
        )

    return FileResponse(
        path=str(clip_path),
        media_type="video/mp4",
        filename=f"{alert_id}.mp4",
        headers={"Content-Disposition": f'attachment; filename="{alert_id}.mp4"'},
    )


# ─────────────────────────────────────────────────────────────────────────────
# Endpoint 5 — Health check
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/health", summary="System status", tags=["System"])
async def health():
    stats = state.evidence_stats()
    return {
        "status":         "ok" if state.running else "starting",
        "source":         str(VIDEO_SOURCE),
        "threshold":      state.get_threshold(),         # live value, not startup default
        "alert_cooldown": ALERT_COOLDOWN,
        "device":         "cuda" if torch.cuda.is_available() else "cpu",
        "clips_ready":    stats["ready"],
        "clips_writing":  stats["writing"],
        "clips_error":    stats["error"],
        "evidence_dir":   str(EVIDENCE_DIR.resolve()),
    }
