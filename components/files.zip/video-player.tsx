"use client"

import { useState, useEffect, useRef } from "react"
import { Repeat, Timer, Radio, Play, Pause, Maximize2, WifiOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

// ─── Types ────────────────────────────────────────────────────────────────────

export interface LiveAlert {
  id:         string
  timestamp:  string
  isoTime:    string
  confidence: number
  type:       "Violence"
  severity:   "critical" | "high" | "medium"
  cameraId:   string
  location:   string
}

interface VideoPlayerProps {
  activeAlert: LiveAlert | null
  privacyMode: boolean
}

// ─── Constants ────────────────────────────────────────────────────────────────

const VIDEO_FEED_URL = "http://localhost:8000/video_feed"
const CAMERA_LABEL   = "CAM-01 — Live Feed"

/**
 * How long (ms) the violence overlay stays visible after the last alert.
 * Once no new alert arrives within this window the overlay fades out and the
 * player reverts to the green "Monitoring" state.
 */
const OVERLAY_LINGER_MS = 8_000

// ─── Component ────────────────────────────────────────────────────────────────

export function VideoPlayer({ activeAlert, privacyMode }: VideoPlayerProps) {
  const [isPlaying,     setIsPlaying]     = useState(true)
  const [activeControl, setActiveControl] = useState<string | null>(null)
  const [streamError,   setStreamError]   = useState(false)

  /**
   * showViolence drives ALL visual warnings.
   *
   * It is set to true the moment a new (non-null) activeAlert arrives and
   * automatically cleared OVERLAY_LINGER_MS after the last alert, so that a
   * brief violent event doesn't leave permanent red UI stuck on screen.
   *
   * If violence is continuous the timer resets on every new alert, keeping
   * the overlay active for as long as the threat persists.
   */
  const [showViolence, setShowViolence] = useState(false)

  // Snapshot the alert that triggered the current visible overlay so the
  // confidence meter and badge don't flicker when activeAlert flips to null.
  const [visibleAlert, setVisibleAlert] = useState<LiveAlert | null>(null)

  const lingerTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    if (activeAlert === null) return  // no-op — let the linger timer handle hide

    // New alert arrived — show overlay and capture it for display
    setShowViolence(true)
    setVisibleAlert(activeAlert)

    // Reset the linger timer so it counts from the most recent alert
    if (lingerTimerRef.current !== null) {
      clearTimeout(lingerTimerRef.current)
    }
    lingerTimerRef.current = setTimeout(() => {
      setShowViolence(false)
    }, OVERLAY_LINGER_MS)

    return () => {
      if (lingerTimerRef.current !== null) {
        clearTimeout(lingerTimerRef.current)
      }
    }
  }, [activeAlert?.id])   // trigger only on genuinely new alerts (id change)

  const confidence = visibleAlert?.confidence ?? 0
  const cameraId   = visibleAlert?.cameraId   ?? "CAM-01"
  const timestamp  = visibleAlert?.timestamp  ?? "--:--:-- UTC"

  return (
    <div className="flex h-full flex-col">

      {/* ── Top status banner ─────────────────────────────────────────── */}
      <div
        className={cn(
          "flex items-center gap-2 border-b px-4 py-2 transition-all duration-700",
          showViolence
            ? "border-danger/40 bg-danger/10"
            : "border-border bg-card/60"
        )}
      >
        {showViolence ? (
          <>
            {/* Pulsing danger dot */}
            <span className="relative flex h-2.5 w-2.5 flex-shrink-0">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-danger opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-danger" />
            </span>
            <span className="text-sm font-bold tracking-wide text-danger">
              ⚠&nbsp;VIOLENCE DETECTED — CONFIDENCE {confidence.toFixed(1)}%
            </span>
            <div className="ml-auto flex items-center gap-1.5">
              <span className="font-mono text-[10px] uppercase text-danger/70">Live Alert</span>
            </div>
          </>
        ) : (
          <>
            <span className="relative flex h-2.5 w-2.5 flex-shrink-0">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-success" />
            </span>
            <span className="text-sm font-semibold text-success">
              MONITORING — No Threat Detected
            </span>
            <span className="ml-auto font-mono text-[10px] text-muted-foreground">
              {CAMERA_LABEL}
            </span>
          </>
        )}
      </div>

      {/* ── Video + overlay container ──────────────────────────────────── */}
      <div className="relative flex-1 overflow-hidden bg-black">

        {/* ── Privacy mode overlay ──────────────────────────────────────── */}
        {privacyMode && (
          <div className="absolute inset-0 z-30 flex items-center justify-center backdrop-blur-2xl">
            <span className="rounded-md border border-danger/40 bg-black/60 px-4 py-1.5 font-mono text-sm font-semibold text-danger">
              PRIVACY MODE — FEED REDACTED
            </span>
          </div>
        )}

        {/* ── Stream error fallback ──────────────────────────────────────── */}
        {streamError && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-background/90">
            <WifiOff className="h-10 w-10 text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground">
              Cannot connect to{" "}
              <code className="rounded bg-secondary px-1 text-xs">{VIDEO_FEED_URL}</code>
            </p>
            <Button size="sm" variant="secondary" onClick={() => setStreamError(false)}>
              Retry
            </Button>
          </div>
        )}

        {/* ── Live MJPEG frame ───────────────────────────────────────────── */}
        {!streamError && (
          <img
            src={isPlaying ? VIDEO_FEED_URL : undefined}
            alt="Live CCTV feed — clean stream"
            className="h-full w-full object-cover"
            onError={() => setStreamError(true)}
          />
        )}

        {/* ═══════════════════════════════════════════════════════════════
            CINEMATIC CSS OVERLAYS — all rendered by React, zero OpenCV
            ═══════════════════════════════════════════════════════════════ */}

        {/* ── 1. Animated danger border ─────────────────────────────────── */}
        {showViolence && (
          <div
            className={cn(
              "pointer-events-none absolute inset-0 z-10",
              "rounded-none border-[3px] border-danger",
              // CSS keyframe: rapid double-pulse matching the danger dot rhythm
              "animate-[danger-pulse_1.2s_ease-in-out_infinite]"
            )}
            style={{
              // Inline fallback in case the custom keyframe isn't in globals.css
              // The box-shadow gives an inner red glow for cinematic depth
              boxShadow: "inset 0 0 40px rgba(239,68,68,0.25), 0 0 20px rgba(239,68,68,0.15)",
            }}
          />
        )}

        {/* ── 2. Scanline vignette — always present, intensifies on threat ─ */}
        <div
          className={cn(
            "pointer-events-none absolute inset-0 z-10 transition-opacity duration-700",
            showViolence ? "opacity-60" : "opacity-20"
          )}
          style={{
            background:
              "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.08) 2px, rgba(0,0,0,0.08) 4px)",
          }}
        />

        {/* ── 3. Central "VIOLENCE DETECTED" badge ──────────────────────── */}
        {showViolence && (
          <div className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-start pt-6">
            {/* Large warning banner */}
            <div
              className={cn(
                "flex items-center gap-3 rounded-lg px-6 py-3",
                "border border-danger/50 bg-black/70",
                "backdrop-blur-sm",
                "animate-[fade-in-down_0.3s_ease-out]"
              )}
            >
              {/* Animated siren dots */}
              <span className="flex gap-1">
                <span className="h-2 w-2 rounded-full bg-danger animate-ping" />
                <span className="h-2 w-2 rounded-full bg-danger animate-ping [animation-delay:0.15s]" />
                <span className="h-2 w-2 rounded-full bg-danger animate-ping [animation-delay:0.3s]" />
              </span>

              <div className="flex flex-col items-center">
                <span className="font-mono text-base font-black uppercase tracking-[0.3em] text-danger drop-shadow-lg">
                  ⚠ VIOLENCE DETECTED
                </span>
                <span className="font-mono text-[11px] tracking-widest text-danger/70">
                  AI CONFIDENCE: {confidence.toFixed(1)}% &nbsp;·&nbsp; {timestamp}
                </span>
              </div>

              <span className="flex gap-1">
                <span className="h-2 w-2 rounded-full bg-danger animate-ping [animation-delay:0.3s]" />
                <span className="h-2 w-2 rounded-full bg-danger animate-ping [animation-delay:0.15s]" />
                <span className="h-2 w-2 rounded-full bg-danger animate-ping" />
              </span>
            </div>
          </div>
        )}

        {/* ── 4. Severity chip — top-left corner ────────────────────────── */}
        {showViolence && visibleAlert && (
          <div className="pointer-events-none absolute left-3 top-3 z-20">
            <Badge
              className={cn(
                "h-5 border px-2 font-mono text-[9px] uppercase shadow-md backdrop-blur-sm",
                visibleAlert.severity === "critical"
                  ? "border-danger/40  bg-danger/20  text-danger"
                  : visibleAlert.severity === "high"
                  ? "border-warning/40 bg-warning/20 text-warning"
                  : "border-primary/40 bg-primary/20 text-primary"
              )}
            >
              {visibleAlert.severity}
            </Badge>
          </div>
        )}

        {/* ── 5. REC indicator — top-right ──────────────────────────────── */}
        <div className="pointer-events-none absolute right-3 top-3 z-20 flex items-center gap-1.5">
          <span
            className={cn(
              "h-2 w-2 rounded-full",
              showViolence ? "bg-danger animate-ping" : "bg-danger animate-pulse"
            )}
          />
          <span className="font-mono text-[10px] font-bold text-danger drop-shadow">REC</span>
        </div>

        {/* ── 6. Timestamp + camera ID — bottom-left ────────────────────── */}
        <div className="pointer-events-none absolute bottom-10 left-3 z-20 flex items-center gap-2">
          <span className="font-mono text-[10px] text-white/60 drop-shadow">{timestamp}</span>
          <span className="text-[10px] text-white/30">|</span>
          <span className="font-mono text-[10px] text-primary drop-shadow">{cameraId}</span>
        </div>

        {/* ── 7. Confidence bar — bottom-right ──────────────────────────── */}
        {showViolence && (
          <div className="pointer-events-none absolute bottom-10 right-3 z-20 flex items-center gap-2">
            <span className="font-mono text-[10px] text-white/50 drop-shadow">CONF</span>
            <div className="h-1.5 w-20 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-danger transition-all duration-500"
                style={{ width: `${confidence}%` }}
              />
            </div>
            <span className="font-mono text-[10px] text-danger drop-shadow">
              {confidence.toFixed(1)}%
            </span>
          </div>
        )}

      </div>
      {/* ── End video container ─────────────────────────────────────────── */}

      {/* ── Controls bar ──────────────────────────────────────────────── */}
      <div className="flex items-center justify-between border-t border-border bg-card px-4 py-2">
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 text-muted-foreground hover:bg-secondary hover:text-foreground"
            onClick={() => setIsPlaying((p) => !p)}
            aria-label={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
          </Button>
        </div>

        <div className="flex items-center gap-1">
          <ControlButton
            icon={<Repeat className="h-3.5 w-3.5" />}
            label="Loop Clip"
            isActive={activeControl === "loop"}
            onClick={() => setActiveControl(activeControl === "loop" ? null : "loop")}
          />
          <ControlButton
            icon={<Timer className="h-3.5 w-3.5" />}
            label="Slow Motion"
            isActive={activeControl === "slow"}
            onClick={() => setActiveControl(activeControl === "slow" ? null : "slow")}
          />
          <ControlButton
            icon={<Radio className="h-3.5 w-3.5" />}
            label="Live Feed"
            isActive={activeControl === "live"}
            onClick={() => setActiveControl(activeControl === "live" ? null : "live")}
          />
          <Button
            variant="ghost"
            size="sm"
            className="h-7 w-7 p-0 text-muted-foreground hover:bg-secondary hover:text-foreground"
            aria-label="Fullscreen"
          >
            <Maximize2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </div>
  )
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function ControlButton({
  icon,
  label,
  isActive,
  onClick,
}: {
  icon:     React.ReactNode
  label:    string
  isActive: boolean
  onClick:  () => void
}) {
  return (
    <Button
      variant="ghost"
      size="sm"
      className={cn(
        "h-7 gap-1.5 px-2 text-[11px]",
        isActive
          ? "bg-primary/15 text-primary hover:bg-primary/20 hover:text-primary"
          : "text-muted-foreground hover:bg-secondary hover:text-foreground"
      )}
      onClick={onClick}
    >
      {icon}
      <span className="hidden lg:inline">{label}</span>
    </Button>
  )
}
